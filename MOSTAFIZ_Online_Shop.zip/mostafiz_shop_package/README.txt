MOSTAFIZ Online Shop

Open index.html in a browser to preview the website.
The site includes product cards with online image links, categories, search, shopping cart, order form and a demo admin panel.

Demo admin login:
Username: mostafiz470
Password: Mostafiz1@

Important:
- This is a front-end demo. Admin credentials are visible in the HTML source and are not secure for a live store.
- Orders are stored only in the same browser/device using localStorage.
- Product images are loaded from Unsplash and require an internet connection.
- For a real online shop, connect a secure backend/database and payment/delivery services before publishing.
